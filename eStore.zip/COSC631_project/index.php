<?php
require_once('lib/all.php');

// sets up a session to store values across different PHP files


session_start();

// head sheets with specified css

	generateHeader("index page", array ("css/loginStyle.css", "css/signupStyle.css"),
		array("http://code.jquery.com/ui/1.9.2/jquery-ui.js", 
		"https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js", 
		"js/jqueryClock.js", "js/handleForm.js", "js/javascript.js", "js/ajax.js"));
	head();

echo <<< ZZEOF

<div id="loginClock"></div>  
<div class="password">
<br><br><br>
        <div class="row">

        <div class="column left">
		 <form action="trylogin.php" method="POST">
                      <h3>Customer Portal</h3>
          
ZZEOF;
	
	// shows error message after submmitting invalid username or password 
	
	if(isset($_SESSION['username']) && isset($_SESSION['password'])){
		echo "<p>Username/Password invalid</p>";
	}
echo "<p>Your username*</p><input type='text' name='username' value='";
	if(isset($_SESSION['username'])){ 
		echo $_SESSION['username'];
		
		// releases session variable username in memory
		
		unset($_SESSION['username']);
	} 
echo "'autofocus><p class='input'>Your password*</p> <input type='password' name='password' value='";
	if(isset($_SESSION['password'])){ 
		echo $_SESSION['password']; 
		
		// releases session variable username in memory
		
		unset($_SESSION['password']);
	} 
echo "'><br /> ";
echo <<< ZZEOF
          <div>
				<input class="center1" type="submit" name="Button1" value="Login">
				<input class="center2" type="button" value="Signup" onclick="window.location='register_form.php'">
          </div>
		  </form>
        </div>


        <div class="column right">
		 <form action="trylogin.php" method="POST">
                      <h3>Administrator Poartal</h3>
ZZEOF;
	
	if(isset($_SESSION['username']) && isset($_SESSION['password'])){
		echo "<p>Username/Password invalid</p>";
	}
echo "<p>Your username*</p><input type='text' name='username' value='";
	if(isset($_SESSION['username'])){ 
		echo $_SESSION['username'];
		
		// releases session variable username in memory
		
		unset($_SESSION['username']);
	} 
echo "'autofocus><p class='input'>Your password*</p> <input type='password' name='password' value='";
	if(isset($_SESSION['password'])){ 
		echo $_SESSION['password']; 
		
		// releases session variable username in memory
		
		unset($_SESSION['password']);
	} 
echo "'><br /> ";
echo <<< ZZEOF
          <div >
          <input class="center3" type="submit" name="Button1" value="Login">
          </div>
		  </form>
        </div>

    </div>

ZZEOF;
	
	if (isset($_SESSION['username']) || isset($_SESSION['password'])){
		unset($_SESSION['username']);
		unset($_SESSION['password']);
	}
echo '<br><br><br><br><br><br>';
?>

<?php
	generateFooter();
?>
