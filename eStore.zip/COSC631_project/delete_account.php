<?php
	require_once('lib/dblibs.php');

	// sets up a session to store values across different PHP files

	
	session_start();
	
    db_connect();
    global $db_connection_handle, $_SESSION;
    $user = $_SESSION['username'];

	// a prepared statements with placeholders ensures
	// only data is transferred to the database

    $sql = "DELETE FROM users WHERE username = '$user'";	
    $stmt = $db_connection_handle->prepare($sql);
	$stmt->execute(array($user));

	// a prepared statements with placeholders ensures
	// only data is transferred to the database

    $sql2 = "DELETE FROM profiles WHERE user = '$user'";	
    $stmt = $db_connection_handle->prepare($sql2);
    $stmt->execute(array($user));
	
	if (isset($_SESSION['password']) || isset($_SESSION['username'])){

		// releases session variable username in memory
		unset($_SESSION['password']);
		unset($_SESSION['username']);
	}
    db_close();
	echo"<script type='text/javascript'>alert('delete successfully'); location='../index.php';</script>";
?>
