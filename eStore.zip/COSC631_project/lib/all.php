
<?php
  require_once('dblibs.php');
  require_once('genlib.php');
  require_once 'config.php';
?>
