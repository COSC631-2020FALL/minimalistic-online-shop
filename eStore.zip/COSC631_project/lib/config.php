
<?php
$DB_FIRST_ADMIN_ONLY=TRUE;

$DBHOST='localhost';
$DBNAME='estore';
$DBUSER='estore';
$DBPASS='password';

$EMAIL='lsa@emich.edu';
?>

