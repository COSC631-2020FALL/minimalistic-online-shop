<?php
require_once('config.php');
$db_connection_handle = NULL;

// creates connection using PDO

function db_connect()
{
    global $DBUSER, $DBPASS, $DBNAME, $db_connection_handle;

	
    // create a connect with specified host and database 
    $db_connection_handle = new PDO("mysql:host=localhost;dbname=$DBNAME", $DBUSER, $DBPASS);
	
    // set the PDO error mode to exception
    $db_connection_handle->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
    // set alphabet to lower case
    $db_connection_handle->setAttribute(PDO::ATTR_CASE, PDO::CASE_LOWER);
}


function db_close(){
	global $db_connection_handle;
	$db_connection_handle = NULL;
}



function db_create_customer_table($drop = TRUE)
{
	global $db_connection_handle;
	if ($drop)
	{
		$sql = "DROP TABLE IF EXISTS Customer";
        
		// uses exec() because no return results
		
		$result = $db_connection_handle->exec($sql);
	}
	$sql = <<<ZZEOF
			CREATE TABLE Customer (
			id INT(11) NOT NULL AUTO_INCREMENT,
			username VARCHAR(30) NOT NULL,
			email VARCHAR(30) NOT NULL,
			phoneno INT(11) NOT NULL,
			password VARCHAR(20) NOT NULL,
			PRIMARY KEY (id)
	)
ZZEOF;

	// uses exec() because no return results
    $result = $db_connection_handle->exec($sql);
	return $result;
}



function db_create_users_table($drop = TRUE)
{
	global $db_connection_handle;
	if ($drop)
	{
		$sql = "DROP TABLE IF EXISTS users";
        
		// uses exec() because no return results
		
		$result = $db_connection_handle->exec($sql);
	}
	$sql = <<<ZZEOF
			CREATE TABLE users (
			id INT(11) NOT NULL AUTO_INCREMENT,
			username VARCHAR(30) NOT NULL,
			email VARCHAR(30) NOT NULL,
			phoneno INT(11) NOT NULL,
			password VARCHAR(20) NOT NULL,
			privilege VARCHAR(30) NOT NULL,
			PRIMARY KEY (id)
	)
ZZEOF;

	// uses exec() because no return results
    $result = $db_connection_handle->exec($sql);
	return $result;
}

  

function generate_tables()
{
	global $DB_FIRST_ADMIN_ONLY;

	if ($DB_FIRST_ADMIN_ONLY == FALSE){
		return TRUE;
	}
	try
	{
		db_connect();
		db_create_customer_table();
		db_create_users_table();
		return TRUE;
	}
	catch (PDOException $e)
	{
		return FALSE;
	}
	db_close();
}


// function adding a new account by administer
// according to different privilege

function db_add_new_user_admin($user, $email, $phoneno, $pass, $priv)
{
	db_connect();
	if (is_username_unique($user))
	{	
		global $db_connection_handle;
		
		//password protection: calculates the SHA-1 hash of password string
		$encry_pass = sha1($pass);
		$user_array = array(':user' => $user, ':email' => $email, ':phoneno' => $phoneno, ':pass' => $encry_pass, ':priv' => $priv);
		$sql = 'INSERT INTO users (username,email,phoneno,password,privilege) VALUES (:user,  :email, :phoneno, :pass, :priv)';
		
		// a prepared statements with placeholders ensure
		// only data is transferred to the database
		$stmt = $db_connection_handle->prepare($sql);
		$stmt->execute($user_array);
		db_close();
		echo "<div align = 'center'><strong>$user has been inserted</strong></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";
	}
	else
		echo "<div align = 'center'><strong>$user has already existed</strong></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";
}

// adds a new account by general user

function db_add_new_user($user, $email, $phoneno, $pass)
{
	db_connect();
	global $db_connection_handle;
	
	//password protection: calculates the SHA-1 hash of password string
	$encry_pass = sha1($pass);
	
	
	$user_array = array(':user' => $user, ':email' => $email, ':phoneno' => $phoneno, ':pass' => $encry_pass);
	$sql = 'INSERT INTO users (username,email,phoneno,password) VALUES (:user, :email, :phoneno, :pass)';
	
	$stmt = $db_connection_handle->prepare($sql);
	$stmt->execute($user_array);
}

function db_add_new_customer($username, $email, $phoneno, $pass)
{
	db_connect();
	global $db_connection_handle;
	
	//password protection: calculates the SHA-1 hash of password string
	$encry_pass = sha1($pass);
	
	
	$user_array = array(':username' => $username, ':email' => $email, ':phoneno' => $phoneno, ':pass' => $encry_pass);
	$sql = 'INSERT INTO customer (username,email,phoneno,password) VALUES (:username, :email, :phoneno, :pass)';
	
	$stmt = $db_connection_handle->prepare($sql);
	$stmt->execute($user_array);
}



// creates connection using mysqli

$connection = new mysqli($DBHOST, $DBUSER, $DBPASS, $DBNAME);
if ($connection->connect_error) die($connection->connect_error);


// issues a query  and outputs an error if fails

function queryMysql($query)
{
	global $connection;
	$result = $connection->query($query);
	if (!$result) die($connection->error);
	return $result;
}

// destroys session and clears data to log users out

function destroySession()
{	
	// sets group of variables
	
	$_SESSION=array(); 

        
	if (session_id() != "" || isset($_COOKIE[session_name()]))
		        
	// destroy cookie with past one month time setting
	setcookie(session_name(), '', time()-2592000, '/');
	session_destroy();
}

// removes potentially malicious code or tags from input

function sanitizeString($var)
{
	global $connection;
        
	$var = strip_tags($var);   // strips a string from HTML, XML, and PHP tags.
	$var = htmlentities($var); // convert some characters to HTML entities
	$var = stripslashes($var); // remove the backslash
	return $connection->real_escape_string($var);
}

function is_username_unique($user)
{
	db_connect();
	global $db_connection_handle;
	$sql = 'SELECT * FROM users WHERE username = :username';
	$stmt = $db_connection_handle->prepare($sql);  
	
	// bindParam() binds a parameter to the specified variable name 
	// binds username to varialble $user
	
	$stmt->bindParam(':username', $user, PDO::PARAM_STR);
	$stmt->execute();
	
	// output associative array data of each row 
	$result = $stmt->fetch(PDO::FETCH_ASSOC); 
	if ($result == FALSE)
		return TRUE;
	else 
		return FALSE;
}


function validatePass($pass)
{
    if (strlen($pass) > 10 || strlen($pass) < 2){
        return FALSE;
    }
    return TRUE;
}

function query_table($tableName, $usr, $col_name)
{
	global $db_connection_handle;
	
    // prepare sql and bind parameters
	
	$sql = 'SELECT ' . $col_name. ' FROM '. $tableName.' WHERE username = :username';
	
	// a prepared statements with placeholders ensures
	// only data is transferred to the database
	$stmt = $db_connection_handle->prepare($sql);  
	$stmt->bindParam(':username', $usr, PDO::PARAM_STR);
	$stmt->execute();
    
	// output all associative array data
	
	$result = $stmt->fetchAll(PDO::FETCH_ASSOC); 
	return $result;
}

function delete_id_admin($id)
{
	db_connect();
	if (query_id('title', $id, 'id'))
	{
		global $db_connection_handle, $_SESSION;
		
		$sql = 'DELETE FROM title WHERE id = ?';	
		$stmt = $db_connection_handle->prepare($sql);
		$stmt->execute(array($id));
		
		db_close();
		echo "<div align = 'center'><strong>$id has been deleted</strong></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";
	}
	else
		echo "<div align = 'center'><strong>$id does not exist</strong></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";
}

function query_id($tableName, $id, $col_name)
{
	global $db_connection_handle;
	
    // prepare sql and bind parameters
	
	$sql = 'SELECT ' . $col_name. ' FROM '. $tableName.' WHERE id = :id';
	
	// a prepared statements with placeholders ensures
	// only data is transferred to the database
	$stmt = $db_connection_handle->prepare($sql);  
	$stmt->bindParam(':id', $id, PDO::PARAM_STR);
	$stmt->execute();
    
	// output all associative array data
	
	$result = $stmt->fetchAll(PDO::FETCH_ASSOC); 
	return $result;
}

function validate_login($username, $password)
{
	db_connect();
	
	$result = query_table('users', $username, '*');
	
	db_close();
	if (count($result) != 0){

		// return the last value of the array

		$userInfo = array_pop($result);

		//password protection: calculates the SHA-1 hash of password string

		if (substr(sha1($password), 0, 20) == $userInfo['password']){
			return TRUE;
		}
	}else return FALSE;
}

function update_user_pass_admin($newPass, $user)
{
	db_connect();
	if (query_table('users', $user, 'username'))
	{
		
		global $_SESSION, $db_connection_handle;
		$sql = "UPDATE users SET password = ? WHERE username = ?";
		
		// a prepared statements with placeholders ensures
		// only data is transferred to the database
		$stmt = $db_connection_handle->prepare($sql);
		
		//password protection: sha1() calculates the SHA-1 hash of password string

		$stmt->execute(array(sha1($newPass), $user));
		db_close();
		echo "<div align = 'center'><strong>$user's password has been updated</strong></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";
	}
	else
		echo "<div align = 'center'><strong>$user does not exist</strong></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";
}
function update_user_pass($newPass)
{
	if (isset($_SESSION['username'])){ 
		db_connect();
		global $_SESSION, $db_connection_handle;
		$user = $_SESSION['username'];
		$sql = "UPDATE users SET password = ? WHERE username = ?";
		
		// a prepared statements with placeholders ensures
		// only data is transferred to the database
		$stmt = $db_connection_handle->prepare($sql);
		
		//password protection: sha1() calculates the SHA-1 hash of password string

		$stmt->execute(array(sha1($newPass), $user));
		db_close();
	}
}
?>