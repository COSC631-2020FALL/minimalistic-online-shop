<?php

// show different types of style sheet

function head()
{
	$userstr = '';

	echo <<< ZZEOF
		<div id="nav">
			<h4 id="title">eStore $userstr</h4>

		</div>
ZZEOF;
	
	if (isset($_SESSION['username']))
	{
		$user     = $_SESSION['username'];
		// set user's logged in name to $userstr
		$userstr  = " ($user)";
}
}

function head0()
{
	$userstr = '';
	
	if (isset($_SESSION['username']))
	{
		$user     = $_SESSION['username'];
		// set user's logged in name to $userstr
		$userstr  = " ($user)";
	echo <<< ZZEOF
		<div id="nav">
			<h4 id="title">eStore $userstr</h4><br/>
			<ul id="navPrt2">
				<li><a href="search.php?form=search">Search</a></li>
				<li><a href="logout.php">Logout</a></li>
				</ul>			
		</div>
ZZEOF;
	}
	else die();
}

function head1()
{
	$userstr = '';
	
	if (isset($_SESSION['username']))
	{
		$user     = $_SESSION['username'];
		// set user's logged in name to $userstr
		$userstr  = " ($user)";

	echo "<div id='nav'><h4 id='title'>Search $userstr</h4><br/>" .
		"<ul id='navPrt2'>" .
		"<li><a href='estore.php'>eStore</a></li>" .
		"<li><a href='espace.php'>eSpace</a></li>" .
		"<li><a href='about.php'>About eStore</a></li>" .
		"<li><a href='contact.php'>Contact Us</a></li>" .
		"<li><a href='logout.php'>Logout</a></li></ul></div>" ;
	}
	else die();
}


function head2()
{
	$userstr = '';
	if (isset($_SESSION['username']))
	{
		$user     = $_SESSION['username'];
		$userstr  = " ($user)";

echo "<div id='nav'>" .
	"<h4 id='title'>eStore $userstr</h4><br/>" .
	"</div></li></ul></div>" ;
	}
	else die();
}

function head3()
{
echo <<< ZZEOF
    <div id="nav">
        <h4 id="title">Welcom to Administration Page</h4><br/>
        <ul id="navPrt2">
            <li class="dropdown">
				<a class="dropbtn">EditItem</a>
				<div class="dropdown-content">
					<a href="administer.php?form=insert">Add</a>
					<a href="administer.php?form=search">Search</a>
				</div>
			</li>
			<li><a href="admin.php">Database</a></li>
            <li><a href="logout.php">Logout</a></li>
			</ul>
    </div>
ZZEOF;
}

function generateHeader($title, $css = array(), $js = array())
{
	header('Content-Type: text/html');
	
	//converts predefined characters to HTML entities
	
	$title = htmlspecialchars($title);
	$link = $script = '';
	
	// sets link tags for out line css
	
	foreach ($css as $cssFile){
		$link .= '<link rel="stylesheet" type="text/css" href="'.$cssFile.'" />';
	}
	
	// sets script tags for out line javascript
	
	foreach ($js as $jsFile){
		$script .= '<script type="application/javascript" src="'.$jsFile.'"></script>';
	}
	echo <<<ZZEOF
	<!DOCTYPE html>
	<html>
	<head>
	<title>$title</title>
ZZEOF;
	if ($link != ''){ 
		echo $link;
	}
	if ($script != ''){ 
		echo $script;
	}
	echo <<<ZZEOF
	</head>
	<body>
ZZEOF;
}


// gets document last modified date
// sets copy sign and date         
function generateFooter (){
echo <<<ZZEOF
     <footer>
        <script>
          var dt=new Date(document.lastModified);   
		  document.write('<hr />&copy;2020	This page was last updated on '+dt.toLocaleString());  
        </script>
     </footer>
ZZEOF;
    exit(0);
}

function logout(){
    global $_SESSION;
    unset($_SESSION['username']);
}
?>