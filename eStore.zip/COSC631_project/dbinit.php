<?php
require_once('lib/all.php');

Session_start();

$result = TRUE;


try
{
	$result = generate_tables();
}
catch (PDOException $e)
{
	$result = FALSE;
}

if ($result === TRUE)
	header('Location: success_created.php');
else
header('Location: error.php');
?>

