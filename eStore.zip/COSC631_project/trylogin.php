<?php
require_once('lib/all.php');

//sets up a session to store values across different PHP files

session_start();

//There are two types of log in manner: administer and visiters

if (isset($_POST['username']) && isset($_POST['password'])){
	
	// removes potentially malicious code or tags from input
	
	$pass = sanitizeString($_POST['password']);
	$user = sanitizeString($_POST['username']);
	
	// username 'admin' is defalt administer
	
	if ('admin' == $user && validate_login($user, $pass)){
		header('Location: administer.php');
	}
	elseif (validate_login($user, $pass))
		header('Location: search.php');
	else 
		echo "<div align = 'center'><strong>The username: $user does not exist!</strong></div>";
}

if(!isset($_SESSION['username'])){

	// save data of input for next time log in

    $_SESSION['password'] = $pass;
    $_SESSION['username'] = $user;
	echo"<script type='text/javascript'>alert('Sing up first!');location='index.php';</script>";
}
?>
