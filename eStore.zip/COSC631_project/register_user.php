<?php
require_once 'lib/all.php';
session_start();

$user = $pass = $passConfirm = "";
if (isset($_SESSION['user'])) destroySession();

if (isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['passConfirm']))
{
	$passConfirm = sanitizeString($_POST['passConfirm']);
	$pass = sanitizeString($_POST['pass']);
	$user = sanitizeString($_POST['user']);

	
	if(validatePass($pass) && ($pass === $passConfirm) )
	{
		db_connect();
		if (is_username_unique($user)){			
			db_add_new_user($user, $pass);
			db_close();
			$_SESSION['user'] = $user;
			echo"<script type='text/javascript'>alert('register successfully, you can log in now!');
		   location='index.php';</script>";
		} 
	}
}

if (!isset($_SESSION["user"])){
    $_SESSION['pass'] = $pass;
	$_SESSION['passConfirm'] = $passConfirm;
    $_SESSION['user'] = $user;
    header('Location: register_form.php');
}
?>