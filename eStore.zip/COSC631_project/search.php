<?php
require_once('lib/all.php');

session_start();

generateHeader("Administer Page", array ("css/loginStyle.css", "css/signupStyle.css", "css/searchStyle.css"),
	array("js/dropdownmenu.js", "http://code.jquery.com/ui/1.9.2/jquery-ui.js", 
	"https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js", 
	"js/jqueryClock.js", "js/handleForm.js", "js/javascript.js", "js/ajax.js"));

	head0();

	// Checks if the title is logged in

echo <<< ZZEOF
	<div id="loginClock"></div>
	<div id="body1"><br/>
ZZEOF;


echo <<< ZZEOF
			<div class="password">
				<form action="search.php" method="POST">
					<input type='text' name='item'  autofocus><span id='info'></span>
					<input class='center1' type='submit' name='Button1' value='Search' >
					<input class="center2" type="button" value="Cancel" onclick="window.location='search.php'">
				</form>
			</div><br/><br/><br/><br/>
ZZEOF;

	
echo "</div>";
	generateFooter();

?>



