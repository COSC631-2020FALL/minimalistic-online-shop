<?php 
	require_once 'lib/all.php';
	session_start();

	global $EMAIL;
	$mailing_address=$EMAIL;

function makeContactField($name, $id, $value, $defaultValue, $repopulated){
	echo <<<ZZEOF
	<input id='$id' class='contactField
ZZEOF;
	if($repopulated == 1) echo ' repopField';
	echo <<<ZZEOF
	'; type="text" name='$name' onfocus="clearText('$id', '$defaultValue')" onblur="addText('$id', '$defaultValue')" value='$value' />
ZZEOF;
}


echo <<<ZZEOF

<!DOCTYPE html>
<html>
<head>
	<script type='text/javascript' src='js/contact.js' ></script>
	<script src="//tinymce.cachefly.net/4.0/tinymce.min.js"></script>
	<script>tinymce.init({selector:'textarea'});</script>
</head>
<body>
ZZEOF;


if (isset($_SESSION['username']))
{
	$user     = $_SESSION['username'];
	$loggedin = TRUE;
	$userstr  = " ($user)";
}
else $loggedin = FALSE;

if ($loggedin)
{
	generateHeader("Contact Me", array("css/homeStyle.css"), 
	array("http://code.jquery.com/ui/1.9.2/jquery-ui.js", 
	"https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js", 
	"js/jqueryClock.js"));
	head1();
}
		
$contactArray = array(	'message'	=> array('name' => 'contactMessage', 'value' => 'ENTER YOUR MESSAGE!', 'default' => 'ENTER YOUR MESSAGE!'),
						'name' 		=> array('name' => 'contactName', 	'id' => 'contactNameID', 	'value' => 'NAME',		'default' => 'NAME',	'changed' => 0),
						'email' 	=> array('name' => 'contactEmail',	'id' => 'contactEmailID',	'value' => 'EMAIL', 	'default' => 'EMAIL',	'changed' => 0),
						'subject'	=> array('name' => 'contactSubject','id' => 'contactSubjectID', 'value' => 'SUBJECT',	'default' => 'SUBJECT',	'changed' => 0)		
);

$invalidForm = 0;
$invalidFormMessage='';

if(isset($_POST['submitButton'])){
	
	// Check that all forms are filled
	foreach($contactArray as $contactKey => $fieldArray){
		$postText = strip_tags($_POST[$fieldArray['name']]);
		if($postText == $fieldArray['default'] || $postText == ''){
			$invalidForm = 1;
			$invalidFormMessage=strtoupper($contactKey).' must be filled in!';
		}
		else{
			$contactArray[$contactKey]['changed'] = 1;
		}
	}
	
	// Check that Email address is valid
	if ($invalidForm == 0 && !filter_var($_POST['contactEmail'], FILTER_VALIDATE_EMAIL)) {
		$invalidForm = 1;
		$invalidFormMessage='Invalid Email';
	}
	
	// If invalid, repopulate form
	if($invalidForm == 1){
		foreach($contactArray as $contactKey => $fieldArray){
			$contactArray[$contactKey]['value'] = htmlentities($_POST[$fieldArray['name']]);
		}
	}

	else{
		mail($mailing_address, $_POST['contactSubject'], 
			strip_tags($_POST['contactMessage']). "\n\nA mail from Freddy's Blog \nSent by: " . $_POST['contactName'], 
			"From:" . $_POST['contactEmail']);
	}
}
?>
<div id="loginClock"></div>
<hr/>
<h4> Contact </h4>
<hr/>
<br/><br/>
<form action='contact.php' method='post'>
	<div id='contactArea'>
		<div class='contactDiv'>
		</div>
		<div class='contactDiv'>
			<?php 
				foreach($contactArray as $contactKey => $fieldArray){
					if($contactKey != 'message'){
						makeContactField($fieldArray['name'], $fieldArray['id'], $fieldArray['value'], $fieldArray['default'], $invalidForm*$fieldArray['changed'] );
					}
				}
			?>
		</div>
		<div class='contactDiv'>
			<textarea name='contactMessage' ><?php echo $contactArray['message']['value']?></textarea>
		</div>
		<div class='contactDiv'>
		
			<?php
			
			if($invalidForm == 1) echo<<<ZZEOF
<h3 id='warningTag'>$invalidFormMessage</h3>
ZZEOF;
			elseif(isset($_POST['submitButton'])) echo<<<ZZEOF
<h3 id='successTag'>Message Sent!</h3>
ZZEOF;
			?>
			
			<input name='submitButton' type='submit' value="SUBMIT" id='submitButton' />
		</div>
	</div>
</form>
<br/><br/><br/><br/>
<?php
  generateFooter();
?>

</body>
</html>