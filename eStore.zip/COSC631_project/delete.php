<?php
require_once('lib/all.php');

session_start();

$sql="delete from title where id=$id" ;
if($db->query($sql)){
	header("location:adminster.php"); 
}else{
	echo "fail to delete ! <a href='index.php'>back to table</a>" ; 
}

$db->close();
