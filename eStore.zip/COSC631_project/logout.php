<?php
	require_once('lib/all.php');

	// sets up a session to store values across different PHP files

	session_start();
	logout();
	echo "<script type='text/javascript'>alert('logout successfully!');" .
	 "location='index.php';</script>";
?>

