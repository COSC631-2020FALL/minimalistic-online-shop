<?php
require_once 'lib/all.php';
session_start();

$user = $pass = $passConfirm = $priv = "";
if (isset($_SESSION['user'])) destroySession();

if (isset($_POST['user']) && isset($_POST['priv']) && isset($_POST['pass']) && isset($_POST['passConfirm']))
{
	$passConfirm = sanitizeString($_POST['passConfirm']);
	$pass = sanitizeString($_POST['pass']);
	$user = sanitizeString($_POST['user']);
	$priv = sanitizeString($_POST['priv']);

	if(validatePass($pass) && ($pass === $passConfirm) )
	{
		db_connect();
		if (is_username_unique($user)){
			db_add_new_user_admin($user, $pass, $priv);
			db_close();
			$_SESSION['user'] = $user;
			echo "<script type='text/javascript'>alert('register successfully!');" .
				 "location='displayTable.php';</script>";
		} 
	}
}

if (!isset($_SESSION["user"])){
    $_SESSION['pass'] = $pass;
	$_SESSION['passConfirm'] = $passConfirm;
    $_SESSION['user'] = $user;
	$_SESSION['priv'] = $priv;
    header('Location: register_form_admin.php');
}
?>
