<?php
require_once 'lib/all.php';
?>
  <b>Tables created successfully!</b>
  <button type="button" autofocus onclick="window.location='admin.php'">Confirm</button>
<?php
generateFooter();
?>

