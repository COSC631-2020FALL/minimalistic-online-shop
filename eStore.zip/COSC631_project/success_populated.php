<?php
require_once 'lib/all.php';
?>
  <b>Initiated successfully!</b>
  <button type="button" autofocus onclick="window.location='admin.php'">Confirm</button>
<?php
generateFooter();
?>

