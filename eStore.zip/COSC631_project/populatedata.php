<?php
require_once 'lib/all.php';
session_start();

$list_of_titles = array(
	array('title' => 'Gone With The Wind', 'authername' => 'Erik', 'publisher' => 'MIT', 'language' => 'English', 'price' => '37.00'),
);

$list_of_books = array(
	array('title' => 'Gone With The Wind', 'authername' => 'Erik', 'price' => '37.00'),
);


$list_of_users = array(
	array('username' => 'admin', 'email' => 'lsa@emich.edu', 'phoneno' => '7345468525', 'password' => 'password', 'privilege' => 'admin'),
	array('username' => 'eric', 'email' => 'lsa1@emich.edu', 'phoneno' => '7345468526', 'password' => 'password', 'privilege' => 'user'),
);

$list_of_customers = array(
	array('username' => 'admin', 'email' => 'lsa@emich.edu', 'phoneno' => '7345468525', 'password' => 'password'),
	array('username' => 'eric', 'email' => 'lsa1@emich.edu', 'phoneno' => '7345468526', 'password' => 'password'),
	array('username' => 'sarah', 'email' => 'lsa2@emich.edu', 'phoneno' => '7345468527', 'password' => 'password'),
);

$list_of_authers = array(
    array ('username' => 'eric', 'email' => 'lsa@emich.edu', 'phoneno' => '7345468525'),
);

$list_of_invoices = array(
    array ('value' => '555.00', 'quantity' => '125', 'total' => '5739.00'),
);

db_connect();

while (count($list_of_titles) != 0){
    $title = array_pop($list_of_titles);
    db_add_new_title_admin($title['title'], $title['authername'], $title['publisher'], $title['language'], $title['price']);
}


while (count($list_of_users) != 0){	
    $user = array_pop($list_of_users);
    db_add_new_user_admin($user['username'], $user['email'], $user['phoneno'], $user['password'], $user['privilege']);
}

while (count($list_of_customers) != 0){	
    $customer = array_pop($list_of_customers);
    db_add_new_customer($customer['username'], $customer['email'], $customer['phoneno'], $customer['password']);
}

while (count($list_of_authers) != 0){
    $auther = array_pop($list_of_authers);
    db_add_new_auther($auther['username'], $auther['email'], $auther['phoneno']);
}

while (count($list_of_invoices) != 0){
    $invoice = array_pop($list_of_invoices);
    db_add_new_invoice_item($invoice['value'], $invoice['quantity'], $invoice['total']);
}


db_close();
header('location: success_populated.php');
?>

