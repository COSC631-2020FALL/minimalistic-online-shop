<?php
require_once 'lib/all.php';
Session_start();

generateHeader("update password", array("css/loginStyle.css"), 
	array("js/handleForm.js", "js/javascript.js", "js/ajax.js"));
	
if (isset($_SESSION['username']))
{
	$user     = $_SESSION['username'];
	$loggedin = TRUE;
}
else $loggedin = FALSE;

if ($loggedin)
{  
	if (isset($_SESSION['password']) || isset($_SESSION['passwordConfirm'])){
		unset($_SESSION['password']);
		unset($_SESSION['passwordConfirm']);
	}

echo <<<ZZEOF
<br/><br/><br/><br/><br/><br/>
<div class="password" onmouseover="checkPasswordMatch();">
    <form onsubmit="isFormFilled(this);" method="POST" action="update.php">
        <fieldset id = "field">
		  	<br/><br/><br/>

          <p class="ques">Please enter a new password:</p>
          <input id = "password" type="password" name="password" autofocus >
           <p class="ques">Please enter the password again:</p>
           <input id="confirmPass" type="password" name="passConfirm" onchange="checkPasswordMatch();">
          <div >
          <p id="passwordComparison" ></p>
          <input class="center1" type="submit" name="Button1" value="Submit" onclick="window.location='success_updated.php'"/>
          <input class="center2" type="button" value="Cancel" onclick="window.location='myspace.php'"/>
          </div>
        </fieldset>
      </form>
    </div>
	<br/><br/><br/><br/><br/><br/>
ZZEOF;
}
?>

