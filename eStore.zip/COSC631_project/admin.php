<?php
require_once('lib/all.php');
if ($DB_FIRST_ADMIN_ONLY !== TRUE)
{
?>
<b>YOU MUST SET $DB_FIRST_ADMIN_ONLY = TRUE; in config.php 
to use database!</b>
<a href="administer.php">back</a><br/>
<?php
} else {
?>
<a href="dbinit.php">Initialize Database</a><br/>
<a href="populatedata.php">Populate Database With Example Data</a><br />
<b>WHEN DONE SET $DB_FIRST_ADMIN_ONLY = FALSE; in config.php!</b>
<button type="button" autofocus onclick="window.location='administer.php'">back</button>
<?php
}
?>
</body>
</html>
