
<?php ?>
<!DOCTYPE html>
<html>
<head>
   <title>Permission Denied</title>
</head>
<body>

<h1>Permission Denied</h1>

<p>You cannot access this directory</p>

</body>
</html> 