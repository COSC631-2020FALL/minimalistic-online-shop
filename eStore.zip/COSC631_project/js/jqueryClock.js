
function showTime(){
    var date = new Date();
    var hour = date.getHours();
    var minute = date.getMinutes();
    var second = date.getSeconds();
    
    var showTime = hour + ':' + minute + ':' + second;
    
   $("#loginClock").html(showTime);
}

$(document).ready(function(){
    setInterval('showTime()', 1);
    }        
);
