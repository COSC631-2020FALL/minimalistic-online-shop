<?php
require_once 'lib/all.php';
Session_start();

if ($_POST['password'] == '' || $_POST['passConfirm'] == '')
	echo"<script type='text/javascript'>alert('all fields must be filled');location='updatepw.php';</script>";
elseif (isset($_POST['password']) && isset($_POST['passConfirm']))
{
	if ($_POST['password'] == $_POST['passConfirm'] && validatePass($_POST['password'])){
		update_user_pass($_POST['password']);
		echo"<script type='text/javascript'>alert('update successfully');location='main.php';</script>";
		
	} elseif ($_POST['password'] != $_POST['passConfirm']) {
		echo"<script type='text/javascript'>alert('Passwords not match');location='updatepw.php';</script>";
	}
	else echo"<script type='text/javascript'>alert('Password must contain at least 2 character and no more than 10 characters.');location='updatepw.php';</script>";
}
else header('location: updatepw.php');

	
      
?>

