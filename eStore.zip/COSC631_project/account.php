<?php
require_once 'lib/all.php';
session_start();

generateHeader("Account Management", array("css/homeStyle.css"), 
	array("http://code.jquery.com/ui/1.9.2/jquery-ui.js", 
	"https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js", 
	"js/jqueryClock.js"));
generateNav2();
?>
<div class="account">
	<div class="space"></div>
		<b class="account">Update your password:</b><br/><br/>
		<input type="button" value="Update" onclick="window.location='updatepw.php'"/>
		<div class="space1"></div>
		<b class="account">Delete your account:</b><br/><br/>
		<input type="button" value="Delete" onclick="window.location='delete_account.php'"/>
</div>
	<br/><br/><br/><br/><br/><br/>
<?php
  generateFooter();
?>


