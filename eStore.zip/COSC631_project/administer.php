<?php
require_once('lib/all.php');

session_start();

generateHeader("Administer Page", array("css/dropdown.css", "css/searchStyle.css"), 
	array("js/dropdownmenu.js", "http://code.jquery.com/ui/1.9.2/jquery-ui.js", 
	"https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js", 
	"js/jqueryClock.js", "js/handleForm.js", "js/javascript.js", "js/ajax.js"));

	
// if logged in then show head sheet
	
if (isset($_SESSION['username']))
{
	head3();

	// Checks if the user is logged in
	
	if (isset($_SESSION['username']) && $_SESSION['username'] != 'admin')
	{
		header("HTTP/1.0 401 Unauthorized");
	}

echo <<< ZZEOF
	<div id="loginClock"></div>
	<div id="body1"><br/>
ZZEOF;

if (isset($_GET['form'])) 
{
	switch ($_GET['form'])
	{
		case 'insert':
	echo <<< ZZEOF
			<div class="password">
				<form action="administer.php" method="POST">

					<p>PRICE:</p>
					<input type='text' name='price' autofocus>
					<div >
					<input class='center1' type='submit' name='Button1' value='Add' >
					<input class="center2" type="button" value="Cancel" onclick="window.location='administer.php'">
					</div>
				</form>
			</div><br/><br/><br/><br/><br/><br/><br/><br/>
ZZEOF;
			break;
			
		case 'update':
	echo <<< ZZEOF
			<div class="password">
				<form method='post' action='administer.php'>
					<p>Please enter the username to update:</p>
					<input type='text' name='updateTitle' autofocus>
					<p class="ques">Please enter a password:</p>
					<input id = "password" type="password" name="pass">
					<p class="ques">Please confirm password:</p>
					<input id="confirmPass" type="password" name="passConfirm" onChange='checkPasswordMatch();'>
					<span id="passwordComparison" ></span>
					<div >
					<input class="center1" type="submit" name="Button1" value="Update">
					<input class="center2" type="button" value="Cancel" onclick="window.location='administer.php'">
					</div>
				</form>
			</div><br/><br/><br/><br/><br/><br/><br/><br/>
ZZEOF;
			break;
			

		case 'search':
	echo <<< ZZEOF
			<div class="password">
				<form action="administer.php" method="POST">
					
					<p>PRICE:</p>
					<input type='text' name='price' autofocus>
					<input class='center1' type='submit' name='Button1' value='Search' >
					<input class="center2" type="button" value="Cancel" onclick="window.location='administer.php'">
				</form>
			</div><br/><br/><br/><br/>
ZZEOF;
		
			break;
}
}
}
else
	echo "<div align = 'center'><h2>Please select a management task</h2></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";

echo "</div>";
	generateFooter();

?>


