<?php
require_once 'lib/all.php';
?>
<!DOCTYPE html>
  <b>ERROR: fail to create tables!</b>
  <a href="admin.php">back</a><br/>
<?php
generateFooter();
?>

