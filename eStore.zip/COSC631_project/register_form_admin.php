<?php
require_once 'lib/all.php';
session_start();

generateHeader("admin register page", array("css/dropdown.css", "css/loginStyle.css"), 
	array("js/handleForm.js", "js/javascript.js", "js/ajax.js"));
?>

<div class="password" onmouseover="checkPasswordMatch();">
   <form method='post' action='register_user_admin.php'>
           <fieldset id = "field">
		  	
			<h1>Please Add New User</h1>
			<?php
			if(isset($_SESSION['user']) && isset($_SESSION['priv']) && isset($_SESSION['pass'])){
				echo '<p>Username/Password invalid</p>';
			}
			?>
			<p>Please enter username:</p>
			<input type='text' name='user' value="
			<?php if(isset($_SESSION['user'])){ echo $_SESSION['user']; unset($_SESSION['user']);} ?>"
			onBlur='checkUser(this)' autofocus><span id='info'></span>
			<p>Please enter privilege:</p>
			<input type='text' name='priv' value="
			<?php if(isset($_SESSION['priv'])){ echo $_SESSION['priv']; unset($_SESSION['priv']);} ?>"
			autofocus><span id='info'></span>
			<p class="ques">Please enter a password:</p>
			<input id = "password" type="password" name="pass" value="<?php if(isset($_SESSION['pass'])){ echo $_SESSION['pass']; unset($_SESSION['pass']);} ?>">
			<p class="ques">Please confirm password:</p>
			<input id="confirmPass" type="password" name="passConfirm" value="<?php if(isset($_SESSION['passConfirm'])){ echo $_SESSION['passConfirm']; unset($_SESSION['passConfirm']);} ?>" onchange='checkPasswordMatch();'>
			<span id="passwordComparison" ></span>
			<div >
			<input class="center1" type="submit" name="Button1" value="Submit">
			<input class="center2" type="button" value="Cancel" onclick="window.location='administer.php'">
			</div>
        </fieldset>
      </form>
    </div>
	<br/><br/><br/><br/>
	
