<?php
	require_once 'lib/all.php';

	// sets up a session to store values across different PHP files

	session_start();

	// head sheets with specified css

	generateHeader("rigister page", array ("css/loginStyle.css", "css/searchStyle.css"),
		array("http://code.jquery.com/ui/1.9.2/jquery-ui.js", 
		"https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js", 
		"js/jqueryClock.js", "js/handleForm.js", "js/javascript.js", "js/ajax.js"));
	head();
?>

<div id="loginClock"></div>  
<div class="password" onmouseover="checkPasswordMatch();">
   <form method='post' action='register_user.php'>
        <div class="row">

        <div class="column left">
                      <h1>Create User</h1>
		  <?php
            if(isset($_SESSION['user']) && isset($_SESSION['pass'])){
                echo '<p>Username/Password invalid</p>';
            }
          ?>
		  <p>Please enter your user name:</p>
          <input type='text' name='user' value="<?php if(isset($_SESSION['user'])){ echo $_SESSION['user']; unset($_SESSION['user']);} ?>"
		  onBlur='checkUser(this)' autofocus><span id='info'></span>		          
          <p>Please enter your email:</p>
		  <input type='text' autofocus>
		  <p>Please enter your phone number:</p>
		  <input type='text' autofocus>
          <p class="ques">Please enter a password:</p>
          <input id = "password" type="password" name="pass" value="<?php if(isset($_SESSION['pass'])){ echo $_SESSION['pass']; unset($_SESSION['pass']);} ?>">
           <p class="ques">Please confirm password:</p>
           <input id="confirmPass" type="password" name="passConfirm" value="<?php if(isset($_SESSION['passConfirm'])){ echo $_SESSION['passConfirm']; unset($_SESSION['passConfirm']);} ?>" onchange='checkPasswordMatch();'>
		   <span id="passwordComparison" ></span>
          <div>
				<input class="center1" type="submit" name="Button1" value="Create">
				<input class="center2" type="button" value="Cancel" onclick="window.location='index.php'">
          </div>
        </div>
    </div>
  </form>
</div>
<br/><br/><br/>

<?php
	generateFooter();
?>

